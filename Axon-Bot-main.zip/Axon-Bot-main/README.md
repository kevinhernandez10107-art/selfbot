# Welcome to Axon X Code

- Get Started
-> Make sure the verison of py is 3.11

-> Make sure to downlaod requiremnets.txt

-> That all! All the command and cogs should be synced with your bot

Only 2 step is requires to set this bot!

# Other Changes

-> Change the wavelink in cogs/commands/music.py line 339

-> Change webhook in main.py to your webhook so it can command log

-> Change no preifx logs in cogs/commands/np.py 

-> Change the owner ID In untils/config.py!

-> You can change defualt prefix in ultis/tools.py

# That all 

Enjoy the code to its fullest Preovided By CodeX Developement!

<3

> Main Creds goes to Olympus bot Thanks for this wonderful code and journey!

https://github.com/sonujana26/olympus-bot/blob/main/LICENSE.txt
